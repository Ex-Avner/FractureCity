// =============================================================================
//  Present Palm — Shell Main Process (hub identity; world stays "Fracture City")
//  Boots the launcher window, scans the apps registry, and brokers IPC
//  between renderer (launcher UI), installed apps (running in BrowserWindows),
//  and the on-disk data directory.
// =============================================================================

const { app, BrowserWindow, ipcMain, shell, Menu } = require('electron');
const path = require('path');
const fs = require('fs');
const Registry = require('./services/registry');
const { createPerson } = require('./services/person');
const { createNewswire } = require('./services/newswire');
const Launcher = require('./services/launcher');
const Bus = require('./services/bus');

// ── Resolve the ecosystem root ───────────────────────────────────────────────
// In dev: shell/ is inside Fracture City/, root is the parent.
// In packaged build: extraResources lives under process.resourcesPath.
function resolveRoot() {
  if (app.isPackaged) return process.resourcesPath;
  return path.resolve(__dirname, '..');
}
const ROOT = resolveRoot();
const APPS_DIR   = path.join(ROOT, 'apps');
const DATA_DIR   = path.join(ROOT, 'data');
const SHARED_DIR = path.join(ROOT, 'shared');
const IDEAS_DIR  = path.join(ROOT, 'ideas');

// Ensure data dir exists in dev mode (packaged builds get it from extraResources).
for (const d of [DATA_DIR, IDEAS_DIR]) {
  if (!fs.existsSync(d)) fs.mkdirSync(d, { recursive: true });
}

// ── Services ─────────────────────────────────────────────────────────────────
const registry = new Registry({ appsDir: APPS_DIR });
const launcher = new Launcher({ root: ROOT, registry });
const bus = new Bus();

// ── Windows ──────────────────────────────────────────────────────────────────
let launcherWin = null;

function createLauncher() {
  launcherWin = new BrowserWindow({
    width: 1100,
    height: 720,
    minWidth: 720,
    minHeight: 480,
    backgroundColor: '#080614',
    titleBarStyle: 'hiddenInset',
    trafficLightPosition: { x: 16, y: 16 },
    show: false,
    webPreferences: {
      preload: path.join(__dirname, 'preload-launcher.js'),
      contextIsolation: true,
      nodeIntegration: false,
    },
  });
  launcherWin.once('ready-to-show', () => launcherWin.show());
  launcherWin.loadFile(path.join(__dirname, 'renderer', 'index.html'));

  // Open external links in default browser
  launcherWin.webContents.setWindowOpenHandler(({ url }) => {
    if (url.startsWith('http')) {
      shell.openExternal(url);
      return { action: 'deny' };
    }
    return { action: 'allow' };
  });
}

// ── App lifecycle ────────────────────────────────────────────────────────────
app.whenReady().then(() => {
  buildMenu();
  registry.scan();
  createLauncher();

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createLauncher();
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});

// ── Menu ─────────────────────────────────────────────────────────────────────
function buildMenu() {
  const isMac = process.platform === 'darwin';
  const template = [
    ...(isMac ? [{
      label: app.name,
      submenu: [
        { role: 'about' },
        { type: 'separator' },
        { role: 'hide' }, { role: 'hideOthers' }, { role: 'unhide' },
        { type: 'separator' },
        { role: 'quit' },
      ],
    }] : []),
    // Edit menu — without this, Cmd+C/Cmd+V/Cmd+X/Cmd+A don't fire inside
    // any app launched from the shell. The Visitor's Horde-key paste box
    // and every other input field in every other Fracture City app
    // depend on these accelerators existing at the app menu level.
    { role: 'editMenu' },
    {
      label: 'View',
      submenu: [
        { label: 'Launcher',
          accelerator: 'CmdOrCtrl+L',
          click: () => { if (!launcherWin) createLauncher(); else launcherWin.focus(); }},
        { label: 'Rescan Apps',
          accelerator: 'CmdOrCtrl+R',
          click: () => { registry.scan(); if (launcherWin) launcherWin.webContents.send('registry:updated'); }},
        { type: 'separator' },
        { role: 'reload' },
        { role: 'toggleDevTools' },
      ],
    },
    { role: 'windowMenu' },
  ];
  Menu.setApplicationMenu(Menu.buildFromTemplate(template));
}

// ── IPC handlers ─────────────────────────────────────────────────────────────
ipcMain.handle('registry:list', () => registry.list());
ipcMain.handle('registry:rescan', () => { registry.scan(); return registry.list(); });

// ── Centralized provider config (shared across all apps) ─────────────────────
// Stored at data/_shell/providers.json. Apps read it via window.fracture.
// Shell Settings panel writes to it.
const PROVIDERS_PATH = path.join(DATA_DIR, '_shell', 'providers.json');
function readProviders() {
  try {
    if (!fs.existsSync(PROVIDERS_PATH)) return defaultProviders();
    return JSON.parse(fs.readFileSync(PROVIDERS_PATH, 'utf8'));
  } catch (e) {
    return defaultProviders();
  }
}
function writeProviders(p) {
  const dir = path.dirname(PROVIDERS_PATH);
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  fs.writeFileSync(PROVIDERS_PATH, JSON.stringify(p, null, 2));
}
function defaultProviders() {
  return {
    preferred: 'pollinations',
    aihorde:      { key: '',          model: 'stable_diffusion' },
    pollinations: { token: '',        model: 'turbo' },
    huggingface:  { token: '',        model: 'black-forest-labs/FLUX.1-schnell' },
    openai:       { key: '',          model: 'gpt-image-1' },
  };
}
ipcMain.handle('providers:read', () => readProviders());
ipcMain.handle('providers:write', (event, p) => { writeProviders(p); return true; });

// ── The person using this install ────────────────────────────────────────────
//  data/_shell/person.json, following the same pattern providers.json above
//  established: written by the shell, read by every app, owned by none.
//
//  This is here because every other write in the system is namespaced to an app
//  by construction — data:save takes the slug from the launch argument — so no
//  app could store a record belonging to a *person* rather than to an app.
//  Essays, usernames and characters that persist are all the same feature
//  underneath: a thing with an owner. This is the owner.
const person = createPerson(DATA_DIR);

ipcMain.handle('person:read',    ()                => person.read());
ipcMain.handle('person:update',  (event, patch)    => person.update(patch));
ipcMain.handle('person:claim',   (event, type, ref) => person.claim(type, ref));
ipcMain.handle('person:release', (event, type, ref) => person.release(type, ref));
//  resolve() is how an app reads something it holds without copying it. The
//  cached_* files under data/ are what happens without this.
ipcMain.handle('person:resolve',    (event, ref)  => person.resolve(ref));
ipcMain.handle('person:resolveAll', (event, type) => person.resolveAll(type));

// ── The outside world ────────────────────────────────────────────────────────
//  data/_shell/newswire.json, on the same footing as providers.json and
//  person.json: written by the shell, read by every app, owned by none.
//
//  This is the only thing in the hub that reaches the network, and it lives
//  here for the same reason person.json does — because otherwise every app
//  would have to solve caching, timeouts and being offline all over again, and
//  because an app in a BrowserWindow has no business making arbitrary outbound
//  requests on the user's machine.
//
//  read() answers instantly from cache and never rejects. refresh() is the one
//  that touches the wire.
const newswire = createNewswire(DATA_DIR);

ipcMain.handle('newswire:read',    ()             => newswire.read());
ipcMain.handle('newswire:refresh', (event, force) => newswire.refresh(!!force));

//  Warm it once shortly after boot, off the critical path, so the first app to
//  ask has something to show. A failure here is not an error — it is a city
//  with no signal, which the crawl already knows how to say.
app.whenReady().then(() => {
  setTimeout(() => { newswire.refresh(false).catch(() => {}); }, 2500);
});

// ── Cross-app data read (single-user / single-machine — Avner Media use) ──
// Lets one app read another's stored data, e.g. Visitor reading
// the latest tot.profile.v1 produced by Coherence Assessment.
// Returns null if nothing matches. listKeys returns just filenames.
ipcMain.handle('data:listKeys', (event, otherSlug) => {
  try {
    const dir = path.join(DATA_DIR, otherSlug);
    if (!fs.existsSync(dir)) return [];
    return fs.readdirSync(dir).filter(f => f.endsWith('.json')).map(f => f.replace(/\.json$/, ''));
  } catch (e) { return []; }
});
ipcMain.handle('data:readFrom', (event, otherSlug, key) => {
  try {
    const safeKey = String(key).replace(/[^a-zA-Z0-9._-]/g, '_');
    const p = path.join(DATA_DIR, otherSlug, `${safeKey}.json`);
    if (!fs.existsSync(p)) return null;
    return JSON.parse(fs.readFileSync(p, 'utf8'));
  } catch (e) { return null; }
});

ipcMain.handle('app:open', (event, slug, payload) => launcher.openApp(slug, payload));
ipcMain.handle('app:openExternal', (event, url) => shell.openExternal(url));
ipcMain.handle('app:revealInFinder', (event, slug) => {
  const meta = registry.get(slug);
  if (meta) shell.showItemInFolder(meta.dir);
});

// Data persistence — per-app scoped JSON files in data/<slug>/<key>.json
function dataPath(slug, key) {
  const safeKey = String(key).replace(/[^a-zA-Z0-9._-]/g, '_');
  return path.join(DATA_DIR, slug, `${safeKey}.json`);
}

ipcMain.handle('data:save', (event, slug, key, value) => {
  const dir = path.join(DATA_DIR, slug);
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  fs.writeFileSync(dataPath(slug, key), JSON.stringify(value, null, 2));
  return true;
});

ipcMain.handle('data:read', (event, slug, key) => {
  const p = dataPath(slug, key);
  if (!fs.existsSync(p)) return null;
  try { return JSON.parse(fs.readFileSync(p, 'utf8')); }
  catch (e) { return null; }
});

ipcMain.handle('data:list', (event, slug) => {
  const dir = path.join(DATA_DIR, slug);
  if (!fs.existsSync(dir)) return [];
  return fs.readdirSync(dir)
    .filter(f => f.endsWith('.json'))
    .map(f => f.replace(/\.json$/, ''));
});

ipcMain.handle('data:delete', (event, slug, key) => {
  const p = dataPath(slug, key);
  if (fs.existsSync(p)) { fs.unlinkSync(p); return true; }
  return false;
});

// Bus — pub/sub between running apps
ipcMain.handle('bus:emit', (event, slug, type, payload) => {
  bus.emit(slug, type, payload);
  return true;
});
ipcMain.on('bus:subscribe', (event, type) => {
  bus.subscribe(type, event.sender);
});
