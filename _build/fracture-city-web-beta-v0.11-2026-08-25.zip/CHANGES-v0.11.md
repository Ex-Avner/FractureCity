# Fracture City v0.11 — what changed in this build

This is your `fracturecitywebbookplot20260825.zip` with the campaign intact and
four things fixed on top of it. Nothing in the story was altered.

## Fixed

**The menu was printing three lines of text on top of each other.**
`#menu-overlay .footer` is `position:absolute; bottom:24px`, and the two
campaign/shift notes were given `class="footer"` to borrow its typography — so
both notes and the real footer stacked on the same 24-pixel line and rendered as
garbage. They now use a `menu-note` class that shares the type and stays in the
flow. This bug predates the campaign; it is live on the site right now.

**The version the player reads said v0.10 while the manifest said 0.11.0.**
Both strings now say v0.11, and the class-select subtitle reads
"v0.11 · the second light".

**Every app requested `/favicon.ico` and got a 404.** All fifteen now carry the
same inline SVG icon the landing page uses. No network request.

**The landing page still described v0.10.** The Fracture City card now names the
campaign and says FREE ROAM opts out of it.

## Verified

| suite | result |
|---|---|
| `_verify_story.js` (yours) | pass — six movements, 17 objectives |
| campaign playthrough (new) | 7/7 — runs end to end to THE SECOND LIGHT |
| siege | 24/24 |
| thought bubbles | 18/18 |
| newswire | 16/16 |
| web beta, served as a static site | 12/12 |

The Fourth Watch was checked against the voxel data rather than the code: the
ridge generates at wx=-12, wz=36, and all five chained objective coordinates land
on ridge tops with the water one block lower. The child exists, is in the scene,
and stands 0.7m inside the `arrive` radius.

## Not fixed — a design call, not a bug

The ridge tops sit at y=4; the water surface is at y=3. So the player walks a
metre **above** the waterline, on a visibly dry raised causeway. STORY.md says
the player "crosses stone and sand beneath shallow water" and that others may
call it miraculous — that reading needs the ridge at or just under the surface,
so the water breaks around the player's ankles. Dropping the ridge stamp one
block (`floor-1` to `floor` instead of `floor` to `floor+1`) would do it, but it
also flattens the crossing, and `B_WATER` is `solid:true`, so stepping off the
ridge costs nothing either way. Worth deciding before you ship the chapter.
