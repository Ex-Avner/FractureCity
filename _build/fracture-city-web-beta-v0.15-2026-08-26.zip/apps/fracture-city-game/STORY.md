# Fracture City: The Second Light

## Campaign promise

You work one night as a temporary field witness in a city that survives by forcing contradictory lives into one official account. Every movement asks you to act. None lets you pretend the cost of that action disappeared.

The book is playable structure, not required reading. A player who never opens *The Collapse of Meaning* must still encounter its movement through people, places, systems, and physical choices.

## Spine

Application Q-1957 belongs to Marcus and Clara Vale. Marcus has worked Quarry 4 for eighteen years. Clara wants a small loan to open a general store so he can leave the quarry before it kills him. Their income qualifies them for the loan only while Marcus remains in the job the loan would let him leave.

Daniel at Window Three understands both accounts and denies the application to protect a procedure that also protects him. He is not the villain. The player is given enough authority to act on the file, but never enough to become innocent.

Ned reports every event after the player experiences it. His clean civic language is not exposition. It is the city's mechanism for converting a person back into a manageable surface.

## Six movements

1. **The Evening Report, 18:00.** Residence 14 receives the Vale case. The player leaves the apartment and hears both statements.
2. **The Quarry, 21:10.** Testimony must become material evidence. The player carries stone and inspects Clara's proposed store site.
3. **The Bureau, 00:14.** The player acts on the denied loan. Every available action preserves one truth by putting pressure somewhere else.
4. **The Tow Man, 02:13.** Leon returns one correctly towed car and loses his job. Repair becomes a finite action rather than a fantasy of saving the system.
5. **The Wound That Cannot Close, 03:47.** Seven HOLD cases place the book's wider parables inside the same civic intake.
6. **The Fourth Watch, 05:11.** The interface becomes a route. The player follows exposed ground across Flooded East Road toward a waiting child. The miracle is presence.

## Ending law

Fracture City is not destroyed, exposed, cured, or made coherent. The player reaches another person. At dawn, two realities still fail to become one account, but movement between them remains possible. That is the Second Light.

## Guardrails

- No morality score, empathy points, or hidden perfect ending.
- The player must act. Refusing false closure is not permission to remain passive.
- Daniel, Ned, Leon, Marcus, and Clara remain human under pressure. No single villain carries the thesis.
- The child is a rare witness, not a mascot, oracle, chosen one, ghost, or lore delivery device.
- The Fourth Watch is grounded. The player crosses stone and sand beneath shallow water. Other characters may call it miraculous, but the game does not.
- Book passages may deepen the world, but no required story beat depends on reading a terminal.
