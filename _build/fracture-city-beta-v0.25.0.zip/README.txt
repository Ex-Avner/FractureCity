FRACTURE CITY — public beta build 0.25.0
========================================

DROP THIS FOLDER ON A HOST. THAT IS THE WHOLE INSTALL.

  Cloudflare Pages   drag the unzipped folder onto "Upload assets"
  Netlify            drag the unzipped folder onto the Sites page
  Any static host    upload the contents; index.html is the entry point

It must be served over http(s), not opened as a file:// path — browsers refuse
localStorage and some fetches on file://, and the game saves to localStorage.
Any of `npx serve`, `python3 -m http.server`, or a phone pointed at your laptop
will do for a local look.

WHAT IS IN HERE
---------------
  index.html                    the entire game, one file
  shared/vendor/three.min.js    three.js r158, vendored — no CDN, no network
  _headers / _redirects         caching + SPA fallback for Cloudflare/Netlify

There is no build step, no bundler and no dependency install. Two files and
two host config files.

NO SHELL REQUIRED
-----------------
The game normally runs inside the Present Palm shell, which supplies the save
layer. Out here it defines its own, backed by localStorage under the key
prefix `fracture::fracture-city-game::`. Saves, the world's edits, your
requisitions and which channels the town square is tuned to all persist per
browser, per device. Clearing site data starts a new city.

PHONES
------
Touch controls are built in and appear automatically on any touch device: a
stick bottom-left, drag anywhere to look, buttons bottom-right, and a row of
chips along the top for the board, build mode, items, map and menu. Landscape
is strongly preferred and the game will say so in portrait.

THE TOWN SQUARE NEEDS THE INTERNET (AND NOTHING ELSE DOES)
----------------------------------------------------------
The six public boards read live posts from Mastodon, Hacker News, Bluesky and
Wikipedia's recent-changes feed, straight from the browser, with no API keys
and no server of yours in the middle. All four are readable cross-origin by
design. If a board cannot reach its source it says NO SIGNAL and the game
carries on — it never invents a post.

If your host sets a restrictive Content-Security-Policy, those four hosts need
to be allowed in `connect-src`, or the boards will simply stay empty:

  mastodon.social        the four Mastodon board channels
  hn.algolia.com         the Hacker News board
  public.api.bsky.app    the Bluesky boards
  en.wikipedia.org       the Wikipedia recent-changes board
  hacker-news.firebaseio.com   Ned's headline ticker (separate from the boards)

REPORTING
---------
Useful bug reports say: what you were doing, the district name from the
bottom-left of the HUD, and whether you were on a phone. The seed is in the
save; the menu shows it.
